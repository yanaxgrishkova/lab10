.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Errors
------
