.. spelling::

  Commandline
  commandline

Commandline Tools
-----------------

 - :ref:`pkg.gflags` - contains a C++ library that implements commandline flags processing
 - :ref:`pkg.cxxopts` - Lightweight C++ command line option parser
