.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Build types
-----------

* `Build types like Release/Debug <https://github.com/ruslo/hunter/wiki/example.hunter_configuration_types>`__
