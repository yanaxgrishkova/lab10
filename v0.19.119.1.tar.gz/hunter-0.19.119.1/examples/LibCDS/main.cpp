#include <cds/init.h>

int main()
{
    return 0;
}
