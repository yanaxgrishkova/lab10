#include <boost/chrono/system_clocks.hpp>

int main() {
    boost::chrono::system_clock::now();
    return 0;
}
