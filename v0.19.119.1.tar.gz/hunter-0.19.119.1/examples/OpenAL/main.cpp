#include <AL/al.h>

int main()
{
    return 0;
}
