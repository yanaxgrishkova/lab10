#include <iostream> // std::cout

int main() {
	std::cout << "This program is doing nothing!" << std::endl;
}
