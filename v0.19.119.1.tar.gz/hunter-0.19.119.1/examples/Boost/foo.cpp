#include <boost/predef.h>

int main() {
}
